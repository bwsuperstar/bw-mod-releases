BW AutoClaim - World of Tanks 2.4.0.2
============================================

Claims pet gifts, pet synergy and Clan Supply industrial resource automatically and
shows a daily summary of what you collected. Lists all loaded mods when the game starts.

INSTALL
  1. Close the game.
  2. Extract this archive into your World of Tanks folder
     (the folder that contains WorldOfTanks.exe), allow overwriting.
  3. Start the game.

INCLUDED
  mods/2.4.0.2/bw_autoclaim_1.2.6.wotmod                      BW AutoClaim

  No other mods are needed.

UNINSTALL
  Delete mods/2.4.0.2/bw_autoclaim_1.2.6.wotmod
