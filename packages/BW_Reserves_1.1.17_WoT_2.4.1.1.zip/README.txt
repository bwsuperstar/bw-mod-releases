BW Reserves - World of Tanks 2.4.1.1
=========================================

Automatically re-activates the personal reserves you tick (Combat XP, Credits,
Free & Crew XP) as soon as the running one expires.

INSTALL
  1. Close the game.
  2. Extract this archive into your World of Tanks folder
     (the folder that contains WorldOfTanks.exe), allow overwriting.
  3. Start the game. The first start after installing may restart the game once
     automatically - this is normal (the window gets registered).

USE
  In the garage open the mods list and click "BW Reserves".
  Tick the reserves you want, then press "Reserve ON".
  "Reserve OFF" stops automatic activation.
  Everything is switched off again every time the game closes.

INCLUDED
  mods/2.4.1.1/bw_reserves_1.1.17.wotmod          BW Reserves
  mods/2.4.1.1/me.poliroid.modslistapi_1.8.0.wotmod  Mods list button (required)
  mods/2.4.1.1/net.openwg/net.openwg.gameface_1.2.2.wotmod  Window support (required)

  If you already have a newer modslistapi or gameface, keep only the newest one.

UNINSTALL
  Delete mods/2.4.1.1/bw_reserves_1.1.17.wotmod
