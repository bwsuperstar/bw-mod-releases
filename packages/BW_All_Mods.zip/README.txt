BW Mod Releases - World of Tanks 2.4.1.0

Close the game. Extract this archive into the World of Tanks folder, replacing older BW packages. Remove older bw_*.wotmod files from mods/2.4.1.0 before starting the game.
The protected startup loaders check the shared GitHub release manifest before the garage opens.
