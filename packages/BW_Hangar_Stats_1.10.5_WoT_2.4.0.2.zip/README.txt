BW Hangar Stats - World of Tanks 2.4.0.2
===============================================

Your own random-battle stats on every tank card in the garage: WN8, win rate,
battles, Marks of Excellence and average damage.

INSTALL
  1. Close the game.
  2. Extract this archive into your World of Tanks folder
     (the folder that contains WorldOfTanks.exe), allow overwriting.
  3. Start the game. The first start after installing restarts the game once
     automatically - this is normal (the mod's interface gets registered).

INCLUDED
  mods/2.4.0.2/bw_hangar_stats_1.10.5.wotmod                   BW Hangar Stats
  mods/2.4.0.2/net.openwg/net.openwg.gameface_1.1.6.wotmod       Interface support (required)

  If you already have a newer gameface, keep only the newest one.

UNINSTALL
  Delete mods/2.4.0.2/bw_hangar_stats_1.10.5.wotmod
