BW Network Monitor - World of Tanks 2.4.0.2
==============================================

Shows the current game process connections, the game server reported by game.log,
and an optional ICMP latency check. ICMP is diagnostic and is not the WoT in-game ping.
The connection list includes all mods in the game process. Recent Python HTTP/HTTPS
requests show the originating mod and host/port when detected; CEF/native requests
may remain unattributed.

INSTALL
  1. Close the game.
  2. Extract this archive into the World of Tanks directory.
  3. Start the game. Open the mods list in the garage and select BW Network Monitor.

INCLUDED
  mods/2.4.0.2/bw_network_monitor_0.3.1.wotmod
  mods/2.4.0.2/me.poliroid.modslistapi_1.7.9.wotmod
  mods/2.4.0.2/net.openwg/net.openwg.gameface_1.1.6.wotmod
  mods/configs/bw_network_monitor/BWNetworkGuard.exe   temporary WFP connection controls

BW Tank Stats and BWSTATS uploader ON/OFF controls require BW Tank Stats 1.8.1
and BWSTATS 0.2.2. Those updates are separate packages. Remove the older versions
before installing the updates. The switches reset to ON every game start.

The first use of a connection switch asks for Windows administrator permission.
Only identified optional TCP connections have switches. The game server UDP
connection and unknown WG HTTPS services are protected from blocking. WFP rules
exist only while the helper and game are running, then Windows removes them.

WG UI logging has a master switch and per-feature switches. Cookie names/domains
are displayed without values; the mod does not offer a misleading per-cookie
IP switch. Unknown advertising requests cannot be reliably identified by IP.

This version does not change routing, inspect TLS traffic, or promise lower ping.
