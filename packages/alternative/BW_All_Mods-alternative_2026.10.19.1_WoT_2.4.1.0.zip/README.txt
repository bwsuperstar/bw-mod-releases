BW Mods Alternative builds for World of Tanks 2.4.1.0

Remove the four standard BW packages before installing these alternatives.
Do not install the standard and alternative variant of the same mod together.
