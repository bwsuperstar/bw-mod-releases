BW Hangar Stats Alternative - World of Tanks 2.4.1.0
===============================================

Your own random-battle stats on every tank card in the garage: WN8, win rate,
battles, Marks of Excellence and average damage.

INSTALL
  1. Close the game.
  2. Extract this archive into your World of Tanks folder
     (the folder that contains WorldOfTanks.exe), allow overwriting.
  3. Remove the standard BW Hangar Stats package, then start the game.

INCLUDED
  mods/2.4.1.0/bw_hangar_stats-alternative_1.10.16.wotmod       BW Hangar Stats Alternative
  mods/2.4.1.0/net.openwg/net.openwg.gameface_1.2.2.wotmod       Interface support (required)

  If you already have a newer gameface, keep only the newest one.

UNINSTALL
  Delete mods/2.4.1.0/bw_hangar_stats-alternative_1.10.16.wotmod
