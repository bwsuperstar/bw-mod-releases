BW Tank Stats - World of Tanks 2.4.0.2
=============================================

Shows how good every player in your battle is on the exact tank they are driving:
WN8 in the side panels, your picked stats in TAB and above the vehicles with ALT.

INSTALL
  1. Close the game.
  2. Extract this archive into your World of Tanks folder
     (the folder that contains WorldOfTanks.exe), allow overwriting.
  3. Start the game. The first start after installing restarts the game once
     automatically - this is normal (the mod's windows get registered).

USE
  In battle: side panels show WN8, hold ALT for all picked stats, TAB for the columns.
  In the garage open the mods list and click "BW Tank Stats" to pick up to 3 stats
  per vehicle class, then press "Apply".

INCLUDED
  mods/2.4.0.2/bw_tank_stats_1.8.14.wotmod                     BW Tank Stats
  mods/2.4.0.2/me.poliroid.modslistapi_1.7.9.wotmod              Mods list button (required)
  mods/2.4.0.2/net.openwg/net.openwg.gameface_1.1.6.wotmod       Window support (required)

  If you already have a newer modslistapi or gameface, keep only the newest one.

UNINSTALL
  Delete mods/2.4.0.2/bw_tank_stats_1.8.14.wotmod
